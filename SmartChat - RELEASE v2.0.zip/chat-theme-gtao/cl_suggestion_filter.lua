-- Chat Suggestion Filter for GTAO Theme
-- Hides command suggestions until at least 2 characters after /
-- Removes suggestions starting with /+, /-, /., or /_

local suggestionsToRemove = {}

-- Function to check if a command should be hidden
local function shouldHideSuggestion(command)
    if not command or type(command) ~= "string" then
        return false
    end
    
    -- Remove leading slash for checking
    local cleanCommand = command:gsub("^/", "")
    
    -- Hide if less than 2 characters after /
    if #cleanCommand < 2 then
        return true
    end
    
    -- Hide if starts with +, -, ., or _
    if cleanCommand:match("^[+%-%._]") then
        return true
    end
    
    return false
end

-- Simple approach: Remove suggestions after they're added
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000) -- Check every second
        
        -- Remove any suggestions that match our criteria
        for command, _ in pairs(suggestionsToRemove) do
            TriggerEvent('chat:removeSuggestion', command)
        end
        
        Citizen.Wait(0)
    end
end)

-- Monitor for new suggestions and remove unwanted ones
RegisterNetEvent('chat:addSuggestion')
AddEventHandler('chat:addSuggestion', function(command, helpText, params)
    if shouldHideSuggestion(command) then
        suggestionsToRemove[command] = true
        -- Remove it after a short delay to ensure it was added first
        Citizen.SetTimeout(100, function()
            TriggerEvent('chat:removeSuggestion', command)
        end)
    end
end)

-- Monitor for multiple suggestions
RegisterNetEvent('chat:addSuggestions')
AddEventHandler('chat:addSuggestions', function(suggestions)
    if not suggestions or type(suggestions) ~= "table" then
        return
    end
    
    for _, suggestion in ipairs(suggestions) do
        local command = suggestion.name or suggestion.command or suggestion[1]
        if shouldHideSuggestion(command) then
            suggestionsToRemove[command] = true
            -- Remove it after a short delay
            Citizen.SetTimeout(100, function()
                TriggerEvent('chat:removeSuggestion', command)
            end)
        end
    end
end)

-- Clean up on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        -- Clear the suggestions to remove list
        suggestionsToRemove = {}
    end
end)

print("^2[Chat Filter]^7 Suggestion filtering enabled:")
print("^3- Hiding suggestions with less than 2 characters after /^7")
print("^3- Removing suggestions starting with /+, /-, /., or /_^7")
