local activeBubbles = {}
local FLOAT_DURATION_MS = (Config and Config.FloatDurationMs) or 3300

-- Simple 3D text draw based on common DrawText3D patterns
local function drawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if not onScreen then return end

    local camCoords = GetGameplayCamCoords()
    local dist = #(vector3(x, y, z) - camCoords)

    local scale = (1 / dist) * 2
    local fov = (1 / GetGameplayCamFov()) * 100
    scale = scale * fov

    SetTextScale(0.0 * scale, 0.35 * scale)
    SetTextFont(4)
    SetTextProportional(1)
    local c = (Config and Config.FloatColor) or { r = 255, g = 182, b = 255, a = 255 }
    SetTextColour(c.r or 255, c.g or 182, c.b or 255, c.a or 255)
    SetTextDropshadow(0, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextOutline()
    SetTextCentre(true)

    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(_x, _y)
end

-- Event to show floating text; src is the player source, message is action only (no name)
RegisterNetEvent('local_chat:showFloatingText', function(src, action)
    local ped = GetPlayerPed(GetPlayerFromServerId(src))
    if ped == 0 then return end

    local text = ('* %s *'):format(action)

    local expiresAt = GetGameTimer() + FLOAT_DURATION_MS
    activeBubbles[#activeBubbles + 1] = {
        ped = ped,
        text = text,
        expiresAt = expiresAt
    }
end)

-- Render loop
CreateThread(function()
    while true do
        local now = GetGameTimer()
        for i = #activeBubbles, 1, -1 do
            local b = activeBubbles[i]
            if not DoesEntityExist(b.ped) or now > b.expiresAt then
                table.remove(activeBubbles, i)
            else
                local coords = GetEntityCoords(b.ped)
                -- Slightly above the head
                drawText3D(coords.x, coords.y, coords.z + 1.0, b.text)
            end
        end
        Wait(0)
    end
end)


