local QBCore = nil

-- Try to acquire QBCore gracefully
CreateThread(function()
    local ok, obj = pcall(function()
        return exports['qb-core'] and exports['qb-core']:GetCoreObject()
    end)
    if ok and obj then
        QBCore = obj
    end
end)

-- Helper: get display name (QBCore character or fallback)
local function getDisplayName(src)
    if QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player and Player.PlayerData and Player.PlayerData.charinfo then
            local ci = Player.PlayerData.charinfo
            local first = ci.firstname or 'Unknown'
            return first
        end
    end
    return GetPlayerName(src)
end

-- Compute 3D distance between two player sources
local function distanceBetween(a, b)
    local ap = GetPlayerPed(a)
    local bp = GetPlayerPed(b)
    if not ap or not bp then return 99999.0 end
    local ac = GetEntityCoords(ap)
    local bc = GetEntityCoords(bp)
    return #(ac - bc)
end

-- Word filtering function
local function filterBlacklistedWords(text)
    if not Config.EnableWordFilter or not Config.BlacklistedWords or #Config.BlacklistedWords == 0 then
        return text
    end
    
    local filteredText = text
    for _, word in ipairs(Config.BlacklistedWords) do
        -- Create case-insensitive pattern
        local pattern = ""
        for i = 1, #word do
            local char = word:sub(i, i)
            pattern = pattern .. "[" .. char:lower() .. char:upper() .. "]"
        end
        
        -- Replace all occurrences of the word (case-insensitive)
        filteredText = string.gsub(filteredText, pattern, Config.FilterReplacement)
    end
    
    return filteredText
end

-- Register custom /me command based on configuration
local function registerMeCommand()
    local commandName = Config.OverrideMeCommand and 'me' or Config.AlternativeMeCommand
    local overrideFlag = Config.OverrideMeCommand
    
    
    RegisterCommand(commandName, function(source, args, rawCommand)
    if not args or #args == 0 then return end
    
    local action = table.concat(args, ' ')
    -- Filter blacklisted words from /me command
    action = filterBlacklistedWords(action)
    local name = getDisplayName(source)
    
    
    -- Local routing distances
    -- Chat recipients within configured radius
    local chatRecipients = {}
    -- Floating text recipients within configured radius
    local floatRecipients = {}

    for _, id in ipairs(GetPlayers()) do
        local tid = tonumber(id)
        if tid then
            local dist = distanceBetween(source, tid)
            if dist <= (Config.ChatRadius or 8.0) then
                chatRecipients[#chatRecipients + 1] = tid
            end
            if dist <= (Config.FloatRadius or 3.0) then
                floatRecipients[#floatRecipients + 1] = tid
            end
        end
    end
    
    -- Build /me message payload in light pink/purple (SAMP style)
    local payload = {
        color = { 255, 182, 255 }, -- Light pink/purple (SAMP era feel)
        multiline = true,
        args = { '* ' .. name .. ' ' .. action .. ' *' },
        mode = 'me'
    }
    
    -- Send /me chat to 8m recipients only
    for _, id in ipairs(chatRecipients) do
        TriggerClientEvent('chat:addMessage', id, payload)
    end
    
    -- Send floating text (without name). Optionally hide from the sender.
    for _, id in ipairs(floatRecipients) do
        if Config.ShowFloatingForSelf or id ~= source then
            TriggerClientEvent('local_chat:showFloatingText', id, source, action)
        end
    end
    end, overrideFlag) -- Use configuration to determine override behavior
end

-- Register the command immediately
registerMeCommand()

-- Add a delayed registration as a fallback to ensure our command takes precedence
CreateThread(function()
    Wait(2000) -- Wait 2 seconds for other resources to load
    registerMeCommand()
end)

-- /help and /info: show configured help lines only to the user
local function sendHelpLines(src)
    if type(Config.HelpLines) ~= 'table' or #Config.HelpLines == 0 then
        TriggerClientEvent('chat:addMessage', src, {
            color = { 200, 200, 200 },
            multiline = true,
            args = { 'No help information is configured.' }
        })
        return
    end

    local shown = 0
    for _, line in ipairs(Config.HelpLines) do
        if type(line) == 'string' and line ~= '' then
            TriggerClientEvent('chat:addMessage', src, {
                color = { 200, 200, 200 },
                multiline = true,
                args = { line }
            })
            shown = shown + 1
            if shown >= 6 then break end
        end
    end
end

RegisterCommand('help', function(source, args, raw)
    sendHelpLines(source)
end, false)

RegisterCommand('info', function(source, args, raw)
    sendHelpLines(source)
end, false)

-- Helper: build Twitter custom name from QBCore names
local function buildTwitterName(src)
    local first = getDisplayName(src) or ''
    local last = ''
    -- Try to read last name via QBCore directly for better fidelity
    if QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player and Player.PlayerData and Player.PlayerData.charinfo then
            local ci = Player.PlayerData.charinfo
            first = ci.firstname or first or ''
            last = ci.lastname or ''
        end
    end

    local firstInitial = first:sub(1, 1)
    local lastPart = last:sub(1, 4)
    local totalLen = (#first) + (#last)

    if firstInitial == '' and lastPart == '' then
        return GetPlayerName(src) or 'User'
    end

    return string.format('%s%s%d', firstInitial, lastPart, totalLen)
end

local function sendTweet(src, message)
    if Config.TwitterEnabled == false then
        TriggerClientEvent('chat:addMessage', src, {
            color = { 150, 200, 255 },
            multiline = true,
            args = { 'Twitter is currently disabled.' }
        })
        return
    end

    local customName = buildTwitterName(src)
    local payload = {
        color = { 150, 200, 255 }, -- light blue
        multiline = true,
        args = { ('[Twitter] %s: %s'):format(customName, message) },
        mode = 'twitter'
    }

    for _, id in ipairs(GetPlayers()) do
        TriggerClientEvent('chat:addMessage', tonumber(id), payload)
    end
end

RegisterCommand('tweet', function(source, args, raw)
    if not args or #args == 0 then return end
    sendTweet(source, table.concat(args, ' '))
end, false)

RegisterCommand('tw', function(source, args, raw)
    if not args or #args == 0 then return end
    sendTweet(source, table.concat(args, ' '))
end, false)

RegisterCommand('t', function(source, args, raw)
    if not args or #args == 0 then return end
    sendTweet(source, table.concat(args, ' '))
end, false)

-- /whisper variants: /whisper, /whiser, /wh, /w
local function handleWhisper(source, args)
    if not args or #args < 2 then
        TriggerClientEvent('chat:addMessage', source, {
            color = { 255, 255, 0 },
            multiline = true,
            args = { 'Usage: /whisper [id] [message]' }
        })
        return
    end

    local targetId = tonumber(args[1])
    if not targetId or not GetPlayerName(targetId) then
        TriggerClientEvent('chat:addMessage', source, {
            color = { 255, 255, 0 },
            multiline = true,
            args = { 'Whisper: invalid player id.' }
        })
        return
    end

    table.remove(args, 1)
    local msg = table.concat(args, ' ')
    if msg == '' then
        TriggerClientEvent('chat:addMessage', source, {
            color = { 255, 255, 0 },
            multiline = true,
            args = { 'Whisper: message cannot be empty.' }
        })
        return
    end

    local senderFirst = getDisplayName(source)
    local receiverFirst = getDisplayName(targetId)

    -- Local pink /me-style line to players within 3m (or Config.FloatRadius)
    local radius = (Config.FloatRadius or 3.0)
    local recipients = {}
    for _, id in ipairs(GetPlayers()) do
        local tid = tonumber(id)
        if tid and distanceBetween(source, tid) <= radius then
            recipients[#recipients + 1] = tid
        end
    end

    local pinkPayload = {
        color = { 255, 182, 255 }, -- SAMP-like pink
        multiline = true,
        args = { '* ' .. senderFirst .. ' whispered something to ' .. receiverFirst .. ' *' },
        mode = 'whisper'
    }
    for _, id in ipairs(recipients) do
        TriggerClientEvent('chat:addMessage', id, pinkPayload)
    end

    -- Private gold confirmations
    TriggerClientEvent('chat:addMessage', source, {
        color = { 255, 255, 0 },
        multiline = true,
        args = { '* You whispered to ' .. receiverFirst .. ': ' .. msg .. ' *' }
    })

    TriggerClientEvent('chat:addMessage', targetId, {
        color = { 255, 255, 0 },
        multiline = true,
        args = { '* ' .. senderFirst .. ' whispered ' .. msg .. ' *' }
    })
end

RegisterCommand('whisper', function(source, args, raw)
    handleWhisper(source, args)
end, false)

RegisterCommand('whiser', function(source, args, raw)
    handleWhisper(source, args)
end, false)

RegisterCommand('wh', function(source, args, raw)
    handleWhisper(source, args)
end, false)

RegisterCommand('w', function(source, args, raw)
    handleWhisper(source, args)
end, false)

-- /shout and /s: local shout within (Config.ChatRadius + 10)
local function handleShout(source, args)
    if not args or #args == 0 then return end

    local name = getDisplayName(source)
    local msg = string.upper(table.concat(args, ' ')) .. '!'

    local radius = (Config.ChatRadius or 8.0) + 10.0
    local recipients = {}
    for _, id in ipairs(GetPlayers()) do
        local tid = tonumber(id)
        if tid and distanceBetween(source, tid) <= radius then
            recipients[#recipients + 1] = tid
        end
    end

    local payload = {
        color = { 255, 255, 255 },
        multiline = true,
        args = { name .. ' shouts ' .. msg },
        mode = 'shout'
    }

    for _, id in ipairs(recipients) do
        TriggerClientEvent('chat:addMessage', id, payload)
    end
end

RegisterCommand('shout', function(source, args, raw)
    handleShout(source, args)
end, false)

RegisterCommand('s', function(source, args, raw)
    handleShout(source, args)
end, false)

-- /cclear: clear chat for all clients; restricted to staff licenses
RegisterCommand('cclear', function(source, args, raw)
    if source == 0 then return end -- disallow console by default

    local allowed = false
    if type(Config.StaffLicenses) == 'table' then
        for _, lic in ipairs(Config.StaffLicenses) do
            if GetPlayerIdentifier(source, 0) == lic then
                allowed = true
                break
            end
            if not allowed then
                local i = 0
                while true do
                    local id = GetPlayerIdentifier(source, i)
                    if not id then break end
                    if id == lic then allowed = true break end
                    i = i + 1
                end
                if allowed then break end
            end
        end
    end

    if not allowed then
        TriggerClientEvent('chat:addMessage', source, {
            color = { 255, 0, 0 },
            multiline = true,
            args = { '** You are not authorized to use /cclear **' }
        })
        return
    end

    -- Clear chat for ALL connected clients
    TriggerClientEvent('chat:clear', -1)
end, false)

-- /sa: staff announcement (global), restricted by Config.StaffLicenses (FiveM license identifiers)
RegisterCommand('sa', function(source, args, raw)
    if source == 0 then return end -- disallow console by default
    if not args or #args == 0 then return end

    -- Check permission by license identifier
    local allowed = false
    if type(Config.StaffLicenses) == 'table' then
        for _, lic in ipairs(Config.StaffLicenses) do
            if GetPlayerIdentifier(source, 0) == lic then
                allowed = true
                break
            end
            -- Also scan all identifiers for safety
            if not allowed then
                local i = 0
                while true do
                    local id = GetPlayerIdentifier(source, i)
                    if not id then break end
                    if id == lic then allowed = true break end
                    i = i + 1
                end
                if allowed then break end
            end
        end
    end

    if not allowed then
        TriggerClientEvent('chat:addMessage', source, {
            color = { 255, 0, 0 },
            multiline = true,
            args = { '** You are not authorized to use /sa **' }
        })
        return
    end

    local msg = table.concat(args, ' ')
    local cfxName = GetPlayerName(source) or 'Unknown'

    local payload = {
        color = { 255, 0, 0 },
        multiline = true,
        args = { ('** (( Staff )) %s: %s **'):format(cfxName, msg) },
        mode = 'staff'
    }

    for _, id in ipairs(GetPlayers()) do
        TriggerClientEvent('chat:addMessage', tonumber(id), payload)
    end
end, false)

-- /pm [id] [message]: send a private message between two players (yellow)
RegisterCommand('pm', function(source, args, raw)
    if not args or #args < 2 then
        -- optional: brief usage hint to sender
        TriggerClientEvent('chat:addMessage', source, {
            color = { 255, 255, 0 },
            multiline = true,
            args = { 'Usage: /pm [id] [message]' }
        })
        return
    end

    local targetId = tonumber(args[1])
    if not targetId or not GetPlayerName(targetId) then
        TriggerClientEvent('chat:addMessage', source, {
            color = { 255, 255, 0 },
            multiline = true,
            args = { 'PM: invalid player id.' }
        })
        return
    end

    -- Concatenate message after id
    table.remove(args, 1)
    local msg = table.concat(args, ' ')
    if msg == '' then
        TriggerClientEvent('chat:addMessage', source, {
            color = { 255, 255, 0 },
            multiline = true,
            args = { 'PM: message cannot be empty.' }
        })
        return
    end

    local senderName = GetPlayerName(source) or ('ID ' .. tostring(source))
    local receiverName = GetPlayerName(targetId) or ('ID ' .. tostring(targetId))

    -- Sender confirmation
    TriggerClientEvent('chat:addMessage', source, {
        color = { 255, 255, 0 },
        multiline = true,
        args = { ('PM Sent to %s [%d]: %s'):format(receiverName, targetId, msg) }
    })

    -- Receiver notification
    TriggerClientEvent('chat:addMessage', targetId, {
        color = { 255, 255, 0 },
        multiline = true,
        args = { ('PM From %s [%d]: %s'):format(senderName, source, msg) }
    })
end, false)

-- Helper to send Global/OOC message to all players
local function sendGlobalOOC(src, message)
    if Config.GlobalEnabled == false then
        TriggerClientEvent('chat:addMessage', src, {
            color = { 200, 200, 200 },
            multiline = true,
            args = { 'Global chat is currently disabled.' }
        })
        return
    end
    
    -- Filter blacklisted words from global chat
    local filteredMessage = filterBlacklistedWords(message)
    
    -- If message was filtered, notify the sender
    if filteredMessage ~= message then
        TriggerClientEvent('chat:addMessage', src, {
            color = { 255, 255, 0 },
            multiline = true,
            args = { 'Your global message contained filtered words and was censored.' },
            mode = 'filter'
        })
    end
    
    local cfxName = GetPlayerName(src) or 'Unknown'
    local payload = {
        color = { 200, 200, 200 },
        multiline = true,
        args = { '(( Global )) ' .. cfxName .. ': ' .. filteredMessage },
        mode = 'ooc'
    }

    for _, id in ipairs(GetPlayers()) do
        TriggerClientEvent('chat:addMessage', tonumber(id), payload)
    end
end

-- /o, /ooc, /global aliases for out-of-character/global chat
RegisterCommand('o', function(source, args, raw)
    if not args or #args == 0 then return end
    sendGlobalOOC(source, table.concat(args, ' '))
end, false)

RegisterCommand('ooc', function(source, args, raw)
    if not args or #args == 0 then return end
    sendGlobalOOC(source, table.concat(args, ' '))
end, false)

RegisterCommand('global', function(source, args, raw)
    if not args or #args == 0 then return end
    sendGlobalOOC(source, table.concat(args, ' '))
end, false)

-- /b: local OOC within chat radius: "(( Local )) [cfx name]: message"
RegisterCommand('b', function(source, args, raw)
    if not args or #args == 0 then return end

    local msg = table.concat(args, ' ')
    -- Filter blacklisted words from local OOC chat
    msg = filterBlacklistedWords(msg)
    local cfxName = GetPlayerName(source) or 'Unknown'

    local recipients = {}
    for _, id in ipairs(GetPlayers()) do
        local tid = tonumber(id)
        if tid and distanceBetween(source, tid) <= (Config.ChatRadius or 8.0) then
            recipients[#recipients + 1] = tid
        end
    end

    local payload = {
        color = { 200, 200, 200 },
        multiline = true,
        args = { '(( Local )) ' .. cfxName .. ': ' .. msg },
        mode = 'looc'
    }

    for _, id in ipairs(recipients) do
        TriggerClientEvent('chat:addMessage', id, payload)
    end
end, false)

-- Register custom /do command (SAMP-style): "* message (( Firstname )) *"
RegisterCommand('do', function(source, args, rawCommand)
    if not args or #args == 0 then return end

    local message = table.concat(args, ' ')
    -- Filter blacklisted words from /do command
    message = filterBlacklistedWords(message)
    local name = getDisplayName(source)

    -- Recipients within configured chat radius
    local recipients = {}
    for _, id in ipairs(GetPlayers()) do
        local tid = tonumber(id)
        if tid and distanceBetween(source, tid) <= (Config.ChatRadius or 8.0) then
            recipients[#recipients + 1] = tid
        end
    end

    -- Build /do message payload in light pink/purple (SAMP style)
    local payload = {
        color = { 255, 182, 255 },
        multiline = true,
        args = { '* ' .. message .. ' (( ' .. name .. ' )) *' },
        mode = 'do'
    }

    -- Send to recipients only
    for _, id in ipairs(recipients) do
        TriggerClientEvent('chat:addMessage', id, payload)
    end
end, false)

-- Hook the default chat message flow: intercept plain messages
-- We listen to the built-in chatMessage event and cancel it for plain text (not commands)
AddEventHandler('chatMessage', function(src, author, text)
    if type(text) ~= 'string' then return end

    -- If it starts with '/', let default chat/commands handle it
    if text:sub(1, 1) == '/' then return end

    -- Filter blacklisted words
    local filteredText = filterBlacklistedWords(text)
    
    -- If text was filtered, notify the sender
    if filteredText ~= text then
        TriggerClientEvent('chat:addMessage', src, {
            color = { 255, 255, 0 },
            multiline = true,
            args = { 'Your message contained filtered words and was censored.' },
            mode = 'filter'
        })
    end

    -- Local routing within 10.0 meters
    local name = getDisplayName(src)
    local recipients = {}
    for _, id in ipairs(GetPlayers()) do
        local tid = tonumber(id)
        if tid and distanceBetween(src, tid) <= 10.0 then
            recipients[#recipients + 1] = tid
        end
    end

    -- Build chat message payload compatible with chat resource
    local payload = {
        color = { 255, 255, 255 },
        multiline = true,
        args = { name .. ' says ' .. filteredText },
        mode = 'local'
    }

    -- Send to local recipients only
    for _, id in ipairs(recipients) do
        TriggerClientEvent('chat:addMessage', id, payload)
    end

    -- Cancel the default broadcast
    CancelEvent()
end)


