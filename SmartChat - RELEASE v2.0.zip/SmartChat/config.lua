Config = {}

-- Chat radius (meters)
Config.ChatRadius = 8.0     -- for chat messages
Config.FloatRadius = 3.0    -- for floating text bubble

-- Floating text (/me)
-- If true, the player who types /me will also see the floating text above their head
-- If false, only nearby players (within float radius) will see it
Config.ShowFloatingForSelf = false

-- Floating text duration (ms) - keep in sync with client if desired
Config.FloatDurationMs = 3600

-- Floating text RGBA color for /me bubbles
-- Example SAMP-like light pink/purple
Config.FloatColor = { r = 255, g = 182, b = 255, a = 255 }

-- Staff announcement permissions: list of FiveM license identifiers allowed to use /sa
-- Example: { 'license:1234567890abcdef...', 'license:abcdef1234567890...' }
Config.StaffLicenses = { 'license:21cae7361597f170a204d567e9841703ca87323b' }

-- Toggle for global/OOC chat commands (/o, /ooc, /global)
-- If false, users will receive a notice that global chat is disabled
Config.GlobalEnabled = true

-- Toggle for Twitter commands (/tweet, /tw)
-- If false, users will receive a notice that Twitter is disabled
Config.TwitterEnabled = true

-- /help command info
-- Edit these to customize your server help. Leave empty to disable output.
Config.HelpLines = {
    "Welcome to the server!",
    "Use /me, /do, /b for local RP chat.",
    "Use /tweet or /t to post to Twitter.",
	"Add another line here."
}

-- Blacklist settings
Config.EnableWordFilter = true  -- Set to false to disable word filtering
Config.FilterReplacement = "***"  -- Text to replace blacklisted words with

-- Word blacklist for chat filtering
-- Words in this array will be filtered from chat messages and replaced with the text in Config.FilterReplacement
-- Set to empty table {} to disable word filtering
Config.BlacklistedWords = {
    "tranny",
    -- Add more words as needed
}


-- Command override settings
-- Use this if you have a different /me command you like already
-- If true, the local_chat /me command will override any existing /me command
-- If false, it will use an alternative command name like /melocal
Config.OverrideMeCommand = true

-- Alternative command name if OverrideMeCommand is false
Config.AlternativeMeCommand = "melocal"


--[[

███████╗███████╗
██╔════╝██╔════╝
███████╗███████╗
╚════██║╚════██║
███████║███████║
╚══════╝╚══════╝

Created with love by SmartScripts

For more unique scripts:

smartscripts.tebex.io

discord.gg/smartscripts


--]]

