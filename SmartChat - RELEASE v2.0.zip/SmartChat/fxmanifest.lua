fx_version 'cerulean'
game 'gta5'

name 'SmartChat'
description 'Replace normal chat with better styling and roleplay features.'
author 'SmartScripts'
version '2.0'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

dependencies {
  'chat'
}

escrow_ignore {
  'fxmanifest.lua',
  'config.lua',
  'readme.txt'
}

--[[

███████╗███████╗
██╔════╝██╔════╝
███████╗███████╗
╚════██║╚════██║
███████║███████║
╚══════╝╚══════╝

Created with love by SmartScripts

For more unique scripts:

smartscripts.tebex.io

discord.gg/smartscripts


--]]